const None=()=>{
    return(<>
    <h1>THANK YOU NOTHING HERE!!!</h1>
    
    </>)
}
export default None;