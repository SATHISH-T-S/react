const Register=()=>{
    return(<>
    <div class="adiv">
    <div class="div1">
        <form >
            <div class="div2">
                <h1 class="h1">REGISTER FORM</h1>
                <pre>
            NAME:                  <input type="text" id="name"></input>
<br/>
<br/>
 E-mail:                <input type="text" id="mail"></input>
<br/>
<br/>
Password:              <input type="password" id="pass"></input>
<br/>
<br/>
Confirm Password:      <input type="password" id="cpass"></input>
<br/>
<br/></pre>
<button type="submit" class="btn">REGISTER</button>



</div>
        </form>


    </div>
    </div>
    
    </>)
}
export default Register;